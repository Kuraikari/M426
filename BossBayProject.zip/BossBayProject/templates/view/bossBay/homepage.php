<div class="parallax" >
    <div class="hero-text">
        <h1 style="font-size:50px">BossBay</h1>
        <p>Shopping • Sell • Look and more...</p>
    </div>
</div>

<div id="heroText" class="heroText">
    <h1 id="firsth1" style="font-size:75px">-</h1>
    <h1 style="font-size:30px"> BEST SITE </h1>
    <h1 style="font-size:75px">FOR</h1>
    <h1 style="font-size:35px">SHOP AND SELL</h1>
    <h1 style="font-size:75px">-</h1>
</div>

<div class="parallax2" ></div>

<div id="heroText2" class="heroText2">
    <div class="goTOShop">
      <a href="/BossBay/Shop"  class="btn btn-sm animated-button thar-three">SHOP NOW!</a>
    </div>
</div>
