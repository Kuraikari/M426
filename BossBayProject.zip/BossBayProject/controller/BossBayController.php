<?php

namespace controller;

class BossBayController extends BaseController
{

}
